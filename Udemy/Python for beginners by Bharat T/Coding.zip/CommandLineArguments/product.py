import sys

lst=sys.argv
print("Prodcut is:",int(lst[1])*int(lst[2]))
