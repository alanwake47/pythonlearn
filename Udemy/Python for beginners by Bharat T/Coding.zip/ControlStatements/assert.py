x=int(input("Enter >10 number: "))

assert x>10, "Wrong number entered"

print("U entered",x)