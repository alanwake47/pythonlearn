x=int(input("Enter an interger: "))

for i in range(1,11):
    print(x,'X',i,'=',i*x)