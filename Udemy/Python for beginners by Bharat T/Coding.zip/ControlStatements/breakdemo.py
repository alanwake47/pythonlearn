lst=[3,5,6,9,12]
for i in lst:
    if i==5:
        break
    print(i)