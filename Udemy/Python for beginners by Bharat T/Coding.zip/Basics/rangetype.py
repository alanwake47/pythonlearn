r=range(-9,6,3)

for i in r:
    print(i)
