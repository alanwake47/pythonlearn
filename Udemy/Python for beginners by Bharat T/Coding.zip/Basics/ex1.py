
print ("Hello World!")
print ("Hello Again")
print ("I like typing this.")
print ('Yay!')
print ("I'd much rather you 'not'")
print ('I "said" dont touch this')
print('Hello World')

s="you are sweosme"

print(s.count(s))