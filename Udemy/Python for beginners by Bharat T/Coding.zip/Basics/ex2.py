# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 15:30:04 2019

@author: Aman Krishna
"""

"""comment
two line"""
print("first")