# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 18:04:06 2019

@author: Aman Krishna
"""

a=13
b=100
c=-66
print(a,b,c)


x=33.5
y=-25.8
z=205
print(x,y,z)

d=3+5j
print(d)
print(type(d))

e=0b1010
print(e)

f=0xFF
print(f)

g=True
print(type(g))



