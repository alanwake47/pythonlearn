a,b=10,5

print('Addition: ',a+b)
print('Subtraction: ',a-b)
print('Mul: ',a*b)
print('Division: ',a/b)
print('Mod: ',a%b)
print('Exp: ',a**b)
print('Floor Div: ',a//b)