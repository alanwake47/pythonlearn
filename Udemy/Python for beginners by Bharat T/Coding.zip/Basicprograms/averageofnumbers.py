a,b,c=[int(x) for x in input("Enter three integer numbers separated by space").split()]
avg=(a+b+c)/3
print("Average : %.2f"%(avg))