sid = int(input("Enter Student ID "))
name = input("Enter Student Name ")
marks = float(input("Enter marks scored "))

print("ID:",sid,"Name:",name,"Marks:",marks)