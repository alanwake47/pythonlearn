lst=[2,3,4,5]

result=list(map(lambda n:n*2, lst))

print(result)
for i in result: print(i)