def sum(x,y):
    return x+y

def diff(x,y):
    return x-y

