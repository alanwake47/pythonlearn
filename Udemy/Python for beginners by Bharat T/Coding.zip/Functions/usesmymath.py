import mymath

print(mymath.sum(10,5))
print(mymath.diff(10,5))

from mymath import *

print(sum(10,5))
print(diff(10,5))

import mymath as ma

print(ma.sum(10,5))
print(ma.diff(10,5))

