def average(a=1,b=3): #default values
    #keyword arguments
    print(a)
    print(b)
    return (a+b)/2
    #print("Average of two numbers is",(a+b)/2)
    
result = average(a=30)
print(result)