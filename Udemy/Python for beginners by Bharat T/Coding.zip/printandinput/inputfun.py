'''s=input()
print(s)

s=input("Enter your Name:")

i=int(input("Enter an integer number"))
print(i)'''

lst = [int(x) for x in input("Enter three numbers seprated by space").split(',')]
print(lst)


