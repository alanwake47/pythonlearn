print()
print("Hello"*3)
print("All the power \n is you")

a,b=10,20
print(a,b,sep='++++')

name="john"
marks=94.5

print("Name is",name,"Marks are",marks)
print("Name is %s, Marks are %.2f"%(name,marks))

print("name is {}, Marks are {}".format(name,marks))
print("name is {0}, Marks are {1}".format(name,marks))