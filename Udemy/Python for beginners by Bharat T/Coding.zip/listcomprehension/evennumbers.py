'''lst = [x for x in range(2,21,2)]
print(lst)'''

lst = [x for x in range(1,21) if x%2==0]
print(lst)